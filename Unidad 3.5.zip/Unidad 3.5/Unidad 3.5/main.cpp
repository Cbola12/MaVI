//Bibiliotecas//
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

using namespace sf;

//variables

Texture texture;
Sprite sprite;


float escalaX;
float escalaY;

//Entrada
int main() {

	//cargamos textura

	texture.loadFromFile("plataforma.jpg");

	//cargamos material del sprite
	sprite.setTexture(texture);


	float escalaX = 100.0f / 256.0f;
	float escalaY = 100.0f / 256.0f;

	sprite.setScale(escalaX, escalaY);
	
	//movemos el prite

	sprite.setPosition(400, 300);

	
	

	//Creamos ventana
	sf::RenderWindow App(sf::VideoMode(800, 600, 32),
		"Que ventana Horrible");

	float rotacion = 0.05f;

	//Loop principal
	while (App.isOpen()) {

		float currentRotation = sprite.getRotation();
		float newRotation = currentRotation + rotacion;
		sprite.setRotation(newRotation);


		//limpiamos ventana
		App.clear();

		//Dibujamos escena
		App.draw(sprite);

		//mostramos ventana

		App.display();
	}
	return 0;


}
