//Bibliotecas//
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

using namespace sf;

//Variables//

Texture texture;


Sprite sprite;
Sprite sprite2;
Sprite sprite3;
Sprite sprite4;
Sprite sprite5;
Sprite sprite6;
Sprite sprite7;
Sprite sprite8;


float escalaX;
float escalaY;


//Entrada//

int main() {

	//Cargamos la textura del archivo//
	texture.loadFromFile("plataforma.jpg");


	//cargamos el material del sprite
	sprite.setTexture(texture);
	sprite2.setTexture(texture);
	sprite3.setTexture(texture);
	sprite4.setTexture(texture);
	sprite5.setTexture(texture);
	sprite6.setTexture(texture);
	sprite7.setTexture(texture);
	sprite8.setTexture(texture);

	//escalamos el sprite

	float escalaX = 0.15f;
	float escalaY = 0.15f;

	sprite.setScale(escalaX, escalaY);

	float escalaX2 = 0.15f;
	float escalaY2 = 0.35f;

	sprite2.setScale(escalaX2, escalaY2);

	float escalaX3 = 0.15f;
	float escalaY3 = 0.55f;

	sprite3.setScale(escalaX3, escalaY3);

	float escalaX4 = 0.15f;
	float escalaY4 = 0.75f;

	sprite4.setScale(escalaX4, escalaY4);

	float escalaX5 = 0.15f;
	float escalaY5 = 0.95f;

	sprite5.setScale(escalaX5, escalaY5);

	float escalaX6 = 0.15f;
	float escalaY6 = 1.15f;

	sprite6.setScale(escalaX6, escalaY6);

	float escalaX7 = 0.15f;
	float escalaY7 = 1.35f;

	sprite7.setScale(escalaX7, escalaY7);

	float escalaX8 = 2.0f;
	float escalaY8 = 0.15f;

	sprite8.setScale(escalaX8, escalaY8);


	//Movemos el Sprite

	sprite.setPosition(10, 570);
	sprite2.setPosition(70, 520);
	sprite3.setPosition(130, 470);
	sprite4.setPosition(190, 420);
	sprite5.setPosition(250, 370);
	sprite6.setPosition(310, 320);
	sprite7.setPosition(370, 270);
	sprite8.setPosition(430, 270);
	







	//creamos la ventana

	sf::RenderWindow App(sf::VideoMode(800, 600, 32),
		"Que ventana horrible");


	//loop principal
	while (App.isOpen())
	{

		//limpiamos la ventana
		App.clear();

		//dibujamos la escena
		App.draw(sprite);
		App.draw(sprite2);
		App.draw(sprite3);
		App.draw(sprite4);
		App.draw(sprite5);
		App.draw(sprite6);
		App.draw(sprite7);
		App.draw(sprite8);
		





		//mostramos ventana
		App.display();

	}

	return 0;


}
