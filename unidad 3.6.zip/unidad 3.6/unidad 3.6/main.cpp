//Bibiliotecas//
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

using namespace sf;

//variables

Texture texture_rojo;
Texture texture_amarillo;
Texture texture_negro;
Texture texture_azul;
Texture texture_blanco;
Sprite sprite_rojo;
Sprite sprite_amarillo;
Sprite sprite_negro;
Sprite sprite_azul;
Sprite sprite_blanco;

float escalaX;
float escalaY;
float escalaX2;
float escalaY2;
float escalaX3;
float escalaY3;



//Entrada
int main() {

	//cargamos textura

	texture_rojo.loadFromFile("cuad_red.png");
	texture_amarillo.loadFromFile("cuad_yellow.png");
	texture_negro.loadFromFile("chessb.png");
	texture_azul.loadFromFile("cuad_blue.png");
	texture_blanco.loadFromFile("chessw.png");

	//cargamos material del sprite
	sprite_rojo.setTexture(texture_rojo);
	sprite_amarillo.setTexture(texture_amarillo);
	sprite_negro.setTexture(texture_negro);
	sprite_azul.setTexture(texture_azul);
	sprite_blanco.setTexture(texture_blanco);

	//Escalamos el fondo blanco

	escalaX = 800.0f / 128.0f;
	escalaY = 600.0f / 128.0f;

	sprite_blanco.setScale(escalaX, escalaY);

	escalaX2 = 128.0f / 512.0f;
	escalaY2 = 128.0f / 512.0f;

	sprite_amarillo.setScale(escalaX2, escalaY2);

	escalaX3 = 128.0f / 256.0f;
	escalaY3 = 128.0f / 256.0f;

	sprite_rojo.setScale(escalaX3, escalaY3);

	//movimiento de sprites

	sprite_rojo.setPosition(256, 128);
	sprite_amarillo.setPosition(384, 128);
	sprite_negro.setPosition(384, 256);
	sprite_azul.setPosition(256, 256);

	//Creamos ventana
	sf::RenderWindow App(sf::VideoMode(800, 600, 32),
		"Que ventana Horrible");

	//Loop principal
	while (App.isOpen()) {

		//limpiamos ventana
		App.clear();

		//Dibujamos escena
		App.draw(sprite_blanco);
		App.draw(sprite_amarillo);
		App.draw(sprite_rojo);
		App.draw(sprite_amarillo);
		App.draw(sprite_negro);
		App.draw(sprite_azul);

		//mostramos ventana

		App.display();
	}
	return 0;


}
