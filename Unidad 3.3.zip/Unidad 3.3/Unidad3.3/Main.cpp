//Bibiliotecas//
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

using namespace sf;

//variables

Texture texture;
Sprite fondo;


float escalaX;
float escalaY;

//Entrada
int main() {

	//cargamos textura

	texture.loadFromFile("fondo.jpg");

	//cargamos material del sprite
	fondo.setTexture(texture);

	escalaX = 800.0f / 1024.0f;
	escalaY = 600.0f / 768.0f;

	fondo.setScale(escalaX, escalaY);

	//Creamos ventana
	sf::RenderWindow App(sf::VideoMode(800, 600, 32),
		"Que ventana Horrible");

	//Loop principal
	while (App.isOpen()) {

		//limpiamos ventana
		App.clear();

		//Dibujamos escena
		App.draw(fondo);

		//mostramos ventana

		App.display();
	}
	return 0;


}

